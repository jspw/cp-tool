# __init__.py

# Version of cp-tool
__version__ = "1.0.1"