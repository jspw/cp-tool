# __init__.py

# Version of cp-tool
__version__ = "2.0.0"